chrome.runtime.onInstalled.addListener(() => {
    console.log('Shopee Order Exporter installed.');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'executeScript') {
        chrome.scripting.executeScript({
            target: { tabId: request.tabId },
            files: ['content.js']
        });
    }
});
