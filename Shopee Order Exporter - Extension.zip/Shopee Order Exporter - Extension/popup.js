document.addEventListener('DOMContentLoaded', function() {
    const exportButton = document.getElementById('exportButton');
    const progressContainer = document.getElementById('progressContainer');
    const statusMessage = document.getElementById('statusMessage');
    const progressBar = document.getElementById('progressBar');

    exportButton.addEventListener('click', function() {
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
            chrome.runtime.sendMessage({
                type: 'executeScript',
                tabId: tabs[0].id
            });
            progressContainer.style.display = 'block';
        });
    });

    chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        if (request.type === 'progressUpdate') {
            statusMessage.textContent = request.message;
            progressBar.value = request.progress;
        }
    });
});
